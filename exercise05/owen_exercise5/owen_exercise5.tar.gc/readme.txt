Owen Craston
COMP 3000 exercise 5

part 1: The files associated with this section is evilchild.c and the Makefile in the directory. Run make to compile this program.
type ./evilchild to run the program
 part2: The code for this section is in the /part2 folder and contains primes.c. Run make and ./primes to run the program

