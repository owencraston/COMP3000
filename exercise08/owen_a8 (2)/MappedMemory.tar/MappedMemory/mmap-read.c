/* Mapped-memory example - Reader program
 * Version: March 11, 2018
 */

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include "mmap.h"

int main (int argc, char* const argv[]) {
  int fd;
  void* file_memory;
  int integer;

  /* open the file  */
  fd = open (argv[1], O_RDWR, S_IRUSR | S_IWUSR);

  /* create the memory-mapping */
  file_memory = mmap (NULL, FILESIZE, PROT_READ | PROT_WRITE,
		      MAP_SHARED, fd, 0);
  close (fd);

  /* read and print the integer */
  sscanf (file_memory, "%d", &integer);
  printf ("file contains: %d\n", integer);

  /* release the memory */
  munmap (file_memory, FILESIZE);

  return 0;
}
