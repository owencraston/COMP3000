void owen_time(int * sec, int * nsec);
